package models

type AddressIP struct {
	Address string `json:"ip"`
	Port    string `json:"port"`
}
