
influx  GRANT READ ON my-bucket TO admin
influx GRANT ALL PRIVILEGES TO admin

influx user create --org my-org --name grafana --password


influx user create --token my-super-secret-auth-token  --org my-org --name arng

influx user password --token my-super-secret-auth-token --name brice --password arng123456 

Token my-super-secret-auth-token



