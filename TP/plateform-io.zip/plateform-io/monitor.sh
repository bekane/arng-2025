#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

usage() {
  cat <<'EOF'
Usage: ./monitor.sh [options] [service...]

Streams Docker Compose logs (follows by default). Any service names supplied
limit the output to those services. Common options:
  -n, --no-follow   Show current logs and exit instead of following.
  -t, --tail <n>    Number of log lines to show per service (default: 200).
EOF
}

FOLLOW=true
TAIL=200
POSITIONAL=()

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)
      usage
      exit 0
      ;;
    -n|--no-follow)
      FOLLOW=false
      shift
      ;;
    -t|--tail)
      if [[ $# -lt 2 ]]; then
        echo "Missing value for $1" >&2
        exit 1
      fi
      TAIL="$2"
      shift 2
      ;;
    --)
      shift
      POSITIONAL+=("$@")
      break
      ;;
    -*)
      echo "Unknown option: $1" >&2
      usage
      exit 1
      ;;
    *)
      POSITIONAL+=("$1")
      shift
      ;;
  esac
done

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is required but was not found on PATH." >&2
  exit 1
fi

if docker compose version >/dev/null 2>&1; then
  COMPOSE_CMD=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
  COMPOSE_CMD=(docker-compose)
else
  echo "Neither 'docker compose' nor 'docker-compose' is installed." >&2
  exit 1
fi

HOST_UID=${UID:-$(id -u)}
HOST_GID=${GID:-$(id -g)}

LOG_ARGS=(--tail "$TAIL")
if $FOLLOW; then
  LOG_ARGS+=(-f)
fi

echo "Streaming logs (tail=${TAIL}, follow=${FOLLOW}) ..."
env UID="${HOST_UID}" GID="${HOST_GID}" "${COMPOSE_CMD[@]}" logs "${LOG_ARGS[@]}" "${POSITIONAL[@]}"
