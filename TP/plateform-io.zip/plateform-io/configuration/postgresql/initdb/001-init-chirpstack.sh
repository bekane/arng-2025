#!/bin/bash
#set -e
set -x

psql -v ON_ERROR_STOP=0 --username "$POSTGRES_USER" <<-EOSQL
    create role chirpstack with login password 'chirpstack';
    create database chirpstack with owner chirpstack;
EOSQL
