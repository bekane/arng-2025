#include "lorawan.h"
#include "Arduino.h"

// ------------ LoRaWAN KEYS (MSB order) ---------------
uint8_t deveui[8] = { 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00, 0x01 };
uint8_t appeui[8] = { 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80 };
uint8_t appkey[16] = { 
  0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,
  0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10
};

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("Starting Heltec V3 LoRaWAN device...");

  // Initialize LoRaWAN stack
  LoRaWAN.begin(EU868);
  
  LoRaWAN.setDeviceClass(CLASS_A);
  LoRaWAN.setDataRate(DR_0);   // SF12BW125
  LoRaWAN.setAdaptiveDataRate(true);

  LoRaWAN.setDevEUI(deveui);
  LoRaWAN.setAppEUI(appeui);
  LoRaWAN.setAppKey(appkey);

  Serial.println("Joining...");
  LoRaWAN.joinOTAA();
}

void loop() {
  LoRaWAN.loop();
  
  if (LoRaWAN.joined()) {
      static uint32_t lastSend = 0;
      if (millis() - lastSend > 15000) {
          const char* msg = "HELTEC_V3_OK";
          Serial.println("Sending uplink...");
          LoRaWAN.send(1, (uint8_t*)msg, strlen(msg), false);
          lastSend = millis();
      }
  }
}

