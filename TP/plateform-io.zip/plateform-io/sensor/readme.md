flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
sudo flatpak remote-modify --enable flathub
flatpak update
flatpak install flathub cc.arduino.IDE2

flatpak run cc.arduino.IDE2



sudo usermod -a -G dialout $USER


Fedora:

flatpak override --user --device=all cc.arduino.IDE2
flatpak override --user --filesystem=/dev/ttyUSB0 cc.arduino.IDE2



Sketch lib -> manage :  type Heltec ESP32 Dev-Boards
