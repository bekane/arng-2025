sudo usermod -a -G dialout $USER && \
sudo dnf install git python3-pip python3-pyserial && \
mkdir -p ~/Arduino/hardware/heltec && \
cd ~/Arduino/hardware/heltec && \
git clone https://github.com/Heltec-Aaron-Lee/WiFi_Kit_series.git esp32 && \
cd esp32 && \
git submodule update --init --recursive && \
cd tools && \
python get.py
