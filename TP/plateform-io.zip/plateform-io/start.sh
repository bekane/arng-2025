#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

usage() {
  cat <<'EOF'
Usage: ./start.sh [docker-compose options]

Starts the ChirpStack stack with sane defaults and ensures the UID / GID values
are propagated to Docker Compose so bind-mounted files keep the correct ownership.
Any extra arguments are forwarded to the underlying `docker compose up` call.
EOF
}

if [[ ${1:-} == "-h" || ${1:-} == "--help" ]]; then
  usage
  exit 0
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is required but was not found on PATH." >&2
  exit 1
fi

if docker compose version >/dev/null 2>&1; then
  COMPOSE_CMD=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
  COMPOSE_CMD=(docker-compose)
else
  echo "Neither 'docker compose' nor 'docker-compose' is installed." >&2
  exit 1
fi

HOST_UID=${UID:-$(id -u)}
HOST_GID=${GID:-$(id -g)}

echo "Starting services with UID=${HOST_UID} GID=${HOST_GID} ..."
env UID="${HOST_UID}" GID="${HOST_GID}" "${COMPOSE_CMD[@]}" up -d --remove-orphans "$@"
echo "All containers requested to start. Use ./monitor.sh to tail the logs."
