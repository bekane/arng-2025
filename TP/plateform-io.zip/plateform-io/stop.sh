#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

usage() {
  cat <<'EOF'
Usage: ./stop.sh [docker-compose options]

Gracefully stops the ChirpStack stack. Any additional arguments are forwarded to
`docker compose down`. Pass `-v` (or `--volumes`) to also remove the volumes.
EOF
}

if [[ ${1:-} == "-h" || ${1:-} == "--help" ]]; then
  usage
  exit 0
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is required but was not found on PATH." >&2
  exit 1
fi

if docker compose version >/dev/null 2>&1; then
  COMPOSE_CMD=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
  COMPOSE_CMD=(docker-compose)
else
  echo "Neither 'docker compose' nor 'docker-compose' is installed." >&2
  exit 1
fi

HOST_UID=${UID:-$(id -u)}
HOST_GID=${GID:-$(id -g)}

echo "Stopping services..."
env UID="${HOST_UID}" GID="${HOST_GID}" "${COMPOSE_CMD[@]}" down --remove-orphans "$@"
echo "Stack stopped."
